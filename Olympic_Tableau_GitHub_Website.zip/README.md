# Olympic Analytics — GitHub Pages Website

Responsive static website for the **Global Olympic Sports Performance Analysis** Tableau project.

## Files
- `index.html` — project website
- `style.css` — responsive styling
- `script.js` — dashboard tabs and Tableau embed URLs

## Add Tableau dashboards
1. Publish each dashboard to Tableau Public or your Tableau Server/Cloud.
2. Copy the published share/view URL.
3. Open `script.js` and paste the URLs into `CONFIG.dashboards.d1`, `d2` and `d3`.
4. Replace the GitHub repository URL and Tableau profile URL in the same file.
5. Commit the changes.

The dashboard areas remain placeholders until you add actual published URLs.

## Upload to GitHub
1. Create a repository, e.g. `olympic-tableau-analysis`.
2. Upload `index.html`, `style.css`, `script.js` and `README.md` to the repository root.
3. Commit to the `main` branch.

## Enable GitHub Pages
1. Open repository **Settings → Pages**.
2. Select **Deploy from a branch**.
3. Choose branch `main` and folder `/(root)`.
4. Save. Your site will be published at `https://YOUR-USERNAME.github.io/YOUR-REPOSITORY/`.

## Data limitations
The project brief describes `athlete_events.csv` as 271,116 records across 1896–2016. It does not contain investment, region or a dedicated host-country field. These analyses require verified supplementary data. Medal efficiency is a project-defined measure, not an official Olympic metric. Validate team-event medal counting before reporting final totals.
