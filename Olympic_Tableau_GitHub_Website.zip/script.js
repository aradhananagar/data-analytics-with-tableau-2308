// Paste the published Tableau share URLs here after publishing your dashboards.
const CONFIG = {
  github: "https://github.com/YOUR-USERNAME/YOUR-REPOSITORY",
  tableauProfile: "https://public.tableau.com/",
  dashboards: {
    d1: "", // Dashboard 1 URL
    d2: "", // Dashboard 2 URL
    d3: ""  // Dashboard 3 URL
  }
};

document.querySelectorAll(".tabs button").forEach(button => {
  button.addEventListener("click", () => {
    document.querySelectorAll(".tabs button").forEach(b => b.classList.remove("active"));
    document.querySelectorAll(".panel").forEach(p => p.classList.remove("active"));
    button.classList.add("active");
    document.getElementById(button.dataset.id).classList.add("active");
  });
});

document.querySelectorAll(".embed").forEach(box => {
  const url = CONFIG.dashboards[box.dataset.frame];
  if (!url) return;
  const frame = document.createElement("iframe");
  frame.src = url;
  frame.title = "Olympic Tableau dashboard";
  frame.loading = "lazy";
  frame.allowFullscreen = true;
  box.replaceChildren(frame);
});

document.getElementById("repo").href = CONFIG.github;
document.getElementById("tableau").href = CONFIG.tableauProfile;
document.getElementById("menu").addEventListener("click", () => {
  document.getElementById("nav").classList.toggle("open");
});
document.querySelectorAll("nav a").forEach(a => a.addEventListener("click", () => {
  document.getElementById("nav").classList.remove("open");
}));
